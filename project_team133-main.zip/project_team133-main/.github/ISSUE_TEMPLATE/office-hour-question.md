---
name: Office Hour Question
about: Describe a code-related problem for a TA to look at.
title: ''
labels: ''
assignees: ''

---

<!--
Note: This form is required if you want to show any code to a TA. It is the first thing they will ask you to show!
-->

### Expected behaviour:
<!--- A concise description of what the code is supposed to do. -->

TBD

### Current behaviour:
<!-- A concise description of what the code is doing. -->

TBD

### Additional Information:
<!-- A concise description of what you've done to diagnose the issue. This can include links to the code in question, tests you've written to verify the behaviour and any causes you've ruled out. -->

TBD
