---
name: Schedule
about: Break down tasks and create a schedule for a checkpoint
title: "[Schedule]"
labels: ''
assignees: ''

---

## Breakdown of Tasks

**AddDataset** [assigned-teammate]
- [ ] Task 1

**ListDataset** [assigned-teammate]
- [ ] Task 2

**RemoveDataset** [assigned-teammate]
- [ ] Task 3

**PerformQuery** [assigned-teammate]
- [ ] Task 4

## Schedule
**Date 1**
- [ ] Task 1 [assigned-teammate]

**Date 2**
- [ ] Task 2 [assigned-teammate]
