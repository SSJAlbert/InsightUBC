const config = {
  "trailingComma": "es5",
  "tabWidth": 2,
  "useTabs": true,
  "semi": true,
  "quoteProps": "as-needed",
  "printWidth": 120,
};

module.exports = config;
